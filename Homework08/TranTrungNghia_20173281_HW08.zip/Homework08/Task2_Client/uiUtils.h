#pragma once

#ifndef UI_UTILS_H_
#define UI_UTILS_H_

#include "businessUtils.h"

void startUI();

#endif // !UI_UTILS_H_

