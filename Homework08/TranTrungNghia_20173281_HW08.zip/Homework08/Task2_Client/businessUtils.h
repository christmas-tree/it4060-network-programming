#pragma once

#ifndef BUSINESS_UTILS_H_
#define BUSINESS_UTILS_H_

#include "ioUtils.h"

#include <stdlib.h>
#include <conio.h>

int procReq(short opCode, char* filePath, char* key);

#endif // !BUSINESS_UTILS_H_