#ifndef BUSINESSUTILS_H_
#define BUSINESSUTILS_H_

#include <stdlib.h>
#include <conio.h>

#include "ioUtils.h"

int initData();
int start();

#endif