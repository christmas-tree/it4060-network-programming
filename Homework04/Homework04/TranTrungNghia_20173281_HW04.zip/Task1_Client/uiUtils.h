#pragma once

#ifndef UI_UTILS_H_
#define UI_UTILS_H_

#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "businessUtils.h"

void startUI();

#endif // !UI_UTILS_H_

