#pragma once

#ifndef SERVER_H_
#define SERVER_H_

#include "businessUtils.h"
#include <process.h>
#include <queue>

#define RECEIVE			0
#define SEND			1
#define MAX_CLIENT		5000

#pragma comment(lib, "Ws2_32.lib")

#endif
