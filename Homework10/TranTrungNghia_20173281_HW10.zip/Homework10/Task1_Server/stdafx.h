
#pragma once

#include "targetver.h"
#include <tchar.h>