#define _CRT_SECURE_NO_WARNINGS

#pragma once

#include "targetver.h"
#include <tchar.h>